#include<opencv2/opencv.hpp>
#include<opencv2/core/matx.hpp>
#include<opencv2/core.hpp>
#include"nijvzhen.h"
#include"tps.h"
#include"Byangtiao.h"
#include"jingtaijiance.h"
#include"dongtaijiance.h"
#include"TPS_B.h"

using namespace cv;
using namespace std;

int main()
{
	int a;
	string tu_1 = "C:\\Users\\HASEE\\Desktop\\shuzhifenxi1\\picture\\4.jpg";
	string tezhendian_1 = "C:\\Users\\HASEE\\Desktop\\shuzhifenxi1\\picture\\4.txt";
	string tu_2 = "C:\\Users\\HASEE\\Desktop\\shuzhifenxi1\\picture\\9.jpg";
	string tezhendian_2 = "C:\\Users\\HASEE\\Desktop\\shuzhifenxi1\\picture\\9.txt";
	int wanggejvli = 8;
	//Mat TPS_niuqvtu = TPS_shuangxianxing(tu_2, tezhendian_2, tu_1, tezhendian_1);
	/*Mat TPS_niuqvtu = TPS_shuangsanci(tu_2, tezhendian_2, tu_1, tezhendian_1);*/
	/*Mat TPS_niuqvtu = TPS_zuijinlin(tu_2, tezhendian_2, tu_1, tezhendian_1);*/
	/*Mat B_niuqvtu= Byangtiao_shuangxianxing(tu_1, tezhendian_1, tu_2, tezhendian_2, wanggejvli);*/
	/*Mat B_niuqvtu = Byangtiao_shuangsanci(tu_1, tezhendian_1, tu_2, tezhendian_2, wanggejvli);*/
	
	/*Mat B_niuqvtu = Byangtiao_zuijinlin(tu_1, tezhendian_1, tu_2, tezhendian_2, wanggejvli);*/
	/*imshow("TPSŤ��ͼ", TPS_niuqvtu);*/
	/*imshow("B����Ť��ͼ", B_niuqvtu);*/
	/*jingtaijiance(tu_1);*/
	/*imshow("TPSŤ��ͼ", TPS_niuqvtu);*/
	/*dongtaijiance();*/


	/*Mat tb = TPS_Byangtiao_zuijinlin(tu_1, tezhendian_1, tu_2, tezhendian_2);
	imshow("TPS+B����Ť��", tb);*/

	//double L[N_TB*N_TB];
	//for (int i = 0; i < N_TB; i++)
	//{
	//	for (int j = 0; j < N_TB; j++)
	//	{
	//		if (i == j) { L[i*N_TB + j] = 4; }
	//		else { L[i*N_TB + j] = 0; }
	//		cout << L[i*N_TB + j] << " ";
	//	}
	//	cout << endl;
	//}

	//double *L1 = new double[N_TB*N_TB]();
	//L1 = LUP_solve_inverse_TB(L);
	//cout << "�����Ϊ" << endl;
	//for (int i = 0; i < N_TB; i++)
	//{
	//	for (int j = 0; j < N_TB; j++)
	//	{
	//		cout << L1[i*N_TB+j]<<" ";
	//	}
	//	cout << endl;
	//}
	Mat TB = TPS_Byangtiao_zuijinlin(tu_2, tezhendian_2, tu_1, tezhendian_1,16);
	imshow("TPS_B����Ť��", TB);
	waitKey(0);
}