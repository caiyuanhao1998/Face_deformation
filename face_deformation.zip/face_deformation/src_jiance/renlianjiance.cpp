#include <opencv2/opencv.hpp>
#include <opencv2/face.hpp>
#include "renlianjiance.h"


using namespace std;
using namespace cv;
using namespace cv::face;


int main()
{
	cout << "---------------------��ӭ�����������ϵͳ---------------------" << endl;
	cout << "��̬����밴1" << endl;
	cout << "��̬����밴2" << endl;
	int a;
	cin >> a;
	if (a == 1)
	{
		dongtaijiance();
		waitKey(0);
	}
	if (a == 2)
	{
		cout << "������ͼƬ���(1-9)" << endl;
		int b; cin >> b;
		String a1 = "C:\\Users\\HASEE\\Desktop\\shuzhifenxi1\\picture\\1.jpg";
		String a2 = "C:\\Users\\HASEE\\Desktop\\shuzhifenxi1\\picture\\2.jpg";
		String a3 = "C:\\Users\\HASEE\\Desktop\\shuzhifenxi1\\picture\\3.jpg";
		String a4 = "C:\\Users\\HASEE\\Desktop\\shuzhifenxi1\\picture\\4.jpg";

		String a5 = "C:\\Users\\HASEE\\Desktop\\shuzhifenxi1\\picture\\5.jpg";
		String a6 = "C:\\Users\\HASEE\\Desktop\\shuzhifenxi1\\picture\\6.jpg";
		String a7 = "C:\\Users\\HASEE\\Desktop\\shuzhifenxi1\\picture\\7.jpg";
		String a8 = "C:\\Users\\HASEE\\Desktop\\shuzhifenxi1\\picture\\8.jpg";

		String a9 = "C:\\Users\\HASEE\\Desktop\\shuzhifenxi1\\picture\\9.jpg";

		string tupianlujin;
		if (b == 1) { tupianlujin = a1; }
		if (b == 2) { tupianlujin = a2; }
		if (b == 3) { tupianlujin = a3; }
		if (b == 4) { tupianlujin = a4; }
		if (b == 5) { tupianlujin = a5; }
		if (b == 6) { tupianlujin = a6; }
		if (b == 7) { tupianlujin = a7; }
		if (b == 8) { tupianlujin = a8; }
		if (b == 9) { tupianlujin = a9; }

		Mat img = imread(tupianlujin);
		img = jingtaijiance(img);
		imshow("��̬���", img);
		waitKey(0);
	}
	else
	{
		return(0);
	}
}






